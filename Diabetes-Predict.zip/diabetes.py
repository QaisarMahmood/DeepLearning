import os #import os  this supports operating system–dependent functionality
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Dataset
names = []
glcos = []
ib = []
res=[]
patients = []
folder = '.... here is path of file....'
#print(os.listdir(folder))
filename = 'diabetes.csv'
filepath = os.path.join(folder, filename)

df = pd.read_csv(filepath,usecols=[0, 1, 2,3])
# Create an iterator over the DataFrame rows
row_iterator = df.iterrows()

# Use a while loop to read rows one by one
try:
    while True:
        index, row = next(row_iterator)
        names.append(row.to_dict()['Name'])
        glcos.append(row.to_dict()['Glucose'])
        ib.append(row.to_dict()['BMI'])
        res.append(row.to_dict()['Result'])
        patients.append([glcos[index],ib[index]]);
        
        #break  # Enable this if you want to read one row only
except StopIteration:
    print("No more rows to read.")

# -----------------------------
# Perceptron Class
# -----------------------------
class Perceptron:
    def __init__(self, input_size, learning_rate=0.1, epochs=20):
        self.weights = np.zeros(input_size + 1)  # +1 for bias
        self.lr = learning_rate
        self.epochs = epochs
        self.weight_history = []

    def activation(self, x):
        return 1 if x >= 0 else 0

    def predict(self, x):
        x_with_bias = np.insert(x, 0, 1)
        return self.activation(np.dot(self.weights, x_with_bias))

    def fit(self, X, y):
        for _ in range(self.epochs):
            for xi, target in zip(X, y):
                x_with_bias = np.insert(xi, 0, 1)
                output = self.predict(xi)
                error = target - output
                self.weights += self.lr * error * x_with_bias
            self.weight_history.append(self.weights.copy())

# -----------------------------
# Data: Names, Glucose, BMI, and Labels
# -----------------------------
#names = ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]
X = np.array(patients)
y = np.array(res)

# -----------------------------
# Normalize Features
# -----------------------------
X_mean = X.mean(axis=0)
X_std = X.std(axis=0)
X_normalized = (X - X_mean) / X_std

# -----------------------------
# Train Perceptron
# -----------------------------
model = Perceptron(input_size=2, learning_rate=0.1, epochs=10)
model.fit(X_normalized, y)

# -----------------------------
# Simulate a New User Input
# -----------------------------
#glucose = 135
#bmi = 32
name = input("Enter the Patient Name: ")
glucose = float(input("Enter glucose level: "))
bmi = float(input("Enter BMI: "))
input_features = np.array([glucose, bmi])
standardized_input = (input_features - X_mean) / X_std
prediction = model.predict(standardized_input)
result = name + " : You are at risk of diabetes" if prediction == 1 else name + ": You are not at risk of diabetes"

print(f"\nSimulated Input - Glucose: {glucose}, BMI: {bmi}")
print("Prediction:", result)
# insert data into previous prediction data
new_data = {
    'Name': name,
    'Glucose': glucose,
    'BMI': bmi,
    'Prediction': prediction
}
# Convert to DataFrame
new_row = pd.DataFrame([new_data])  # Note the [ ] around new_data

# Append to existing CSV without writing header again
new_row.to_csv(filepath, mode='a', header=False, index=False)
# -----------------------------
# Predictions for Training Data
# -----------------------------
print("\nPredictions on Training Data:")
for i, sample in enumerate(X_normalized):
    pred = model.predict(sample)
    print(f"Name: {names[i]}, Input: {sample}, Prediction: {pred}, True: {y[i]}")

# -----------------------------
# Plot Decision Boundary with Names
# -----------------------------
def plot_decision_boundary_with_names(model, X, y, names):
    x_min, x_max = X[:, 0].min() - 0.2, X[:, 0].max() + 0.2
    y_min, y_max = X[:, 1].min() - 0.2, X[:, 1].max() + 0.2
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                         np.linspace(y_min, y_max, 100))
    grid = np.c_[xx.ravel(), yy.ravel()]
    Z = np.array([model.predict(point) for point in grid])
    Z = Z.reshape(xx.shape)

    plt.figure(figsize=(10, 6))
    plt.contourf(xx, yy, Z, cmap='RdBu', alpha=0.3)
    scatter = plt.scatter(X[:, 0], X[:, 1], c=y, cmap='bwr', edgecolors='k', s=100)

    for i, name in enumerate(names):
        plt.text(X[i, 0] + 0.02, X[i, 1] + 0.02, name, fontsize=9, color='black')

    plt.xlabel("Glucose (standardized)")
    plt.ylabel("BMI (standardized)")
    plt.title("Decision Boundary with Names (Perceptron)")
    plt.grid(True)
    plt.show()

plot_decision_boundary_with_names(model, X_normalized, y, names)

# -----------------------------
# Bar Chart: Weight Updates
# -----------------------------
weights = np.array(model.weight_history)
epochs = len(weights)
num_weights = weights.shape[1]
bar_width = 0.25
positions = np.arange(epochs)

plt.figure(figsize=(12, 6))
for i in range(num_weights):
    plt.bar(positions + i * bar_width, weights[:, i],
            width=bar_width, label=f'Weight {i}')
plt.xlabel("Epoch")
plt.ylabel("Weight Value")
plt.title("Weight Updates Over Epochs (Bar Chart)")
plt.xticks(positions + bar_width, [f'E{e}' for e in range(epochs)])
plt.legend()
plt.grid(axis='y')
plt.tight_layout()
plt.show()
